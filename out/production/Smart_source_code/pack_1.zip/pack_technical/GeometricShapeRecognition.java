package pack_technical;

public class GeometricShapeRecognition {

    public GeometricShapeRecognition(){

    }
}
