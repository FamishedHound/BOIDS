package pack_technical;


public interface ExampleListener {

    Object notify(Object source);

}
